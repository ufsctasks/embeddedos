#ifndef USER_TASKS_H
#define	USER_TASKS_H

void system_boot(void*);
void temperature_control(void*);
void climate_control(void*);
void lcd_output(void*);

#endif	/* USER_TASKS_H */

