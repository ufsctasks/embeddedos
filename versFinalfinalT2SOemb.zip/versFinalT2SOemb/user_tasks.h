#ifndef USER_TASKS_H
#define	USER_TASKS_H

void system_boot(void*);
void controle_temperatura(void*);
void controle_clima(void*);
void lcd_output(void*);

#endif	/* USER_TASKS_H */

