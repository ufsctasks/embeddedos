#ifndef IO_H
#define	IO_H

#include <xc.h>
#include <stdio.h>

// estados
#define ON 1
#define OFF 0
void hardware_init(void);




void adc_init(void);
int16_t adc_read();

void lcd_port(char);
void lcd_cmd(char);
void lcd_clear(void);
void lcd_set_cursor(char, char);
void lcd_init(void);
void lcd_write_char(char);
void lcd_write_string(const char *);
void lcd_shift_right(void);
void lcd_shift_left(void);

void heating_system(uint8_t);
void cooling_system(uint8_t);
void stable_temperature(uint8_t);


uint8_t read_temperature_increment_button(void);
uint8_t read_temperature_decrement_button(void);

#endif	/* IO_H */

