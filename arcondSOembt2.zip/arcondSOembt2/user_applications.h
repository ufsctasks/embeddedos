#ifndef USER_APPLICATIONS
#define	USER_APPLICATIONS

void system_boot(void*);
void temperature_control(void*);
void climate_control(void*);
void lcd_output(void*);



#endif	/* USER_APPLICATIONS */